import { apiRequest } from './queryClient';

export interface User {
  id: number;
  username: string;
  name: string;
  userType: string;
}

export interface MedicalReport {
  id: number;
  userId: number;
  fileName: string;
  fileType: string;
  fileSize: number;
  uploadedAt: string;
  status: string;
  extractedText: string | null;
  analysisId: number | null;
}

export interface AnalysisResult {
  id: number;
  reportId: number;
  summary: string;
  keyFindings: {
    normal: string[];
    abnormal: string[];
    monitoring: string[];
  };
  abnormalities: {
    severity: 'low' | 'medium' | 'high';
    description: string;
    category: string;
  }[];
  recommendations: {
    category: string;
    text: string;
    priority: 'low' | 'medium' | 'high';
  }[];
  analyzedAt: string;
}

export interface DashboardStats {
  reportsToday: number;
  processing: number;
  abnormalities: number;
}

export const api = {
  getCurrentUser: async (): Promise<User> => {
    const response = await apiRequest('GET', '/api/user');
    return response.json();
  },

  uploadReport: async (file: File): Promise<MedicalReport> => {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch('/api/reports/upload', {
      method: 'POST',
      body: formData,
      credentials: 'include'
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(error || 'Upload failed');
    }

    return response.json();
  },

  getReports: async (): Promise<MedicalReport[]> => {
    const response = await apiRequest('GET', '/api/reports');
    return response.json();
  },

  getReport: async (id: number): Promise<{report: MedicalReport, analysis: AnalysisResult | null}> => {
    const response = await apiRequest('GET', `/api/reports/${id}`);
    return response.json();
  },

  getAnalysis: async (reportId: number): Promise<AnalysisResult> => {
    const response = await apiRequest('GET', `/api/reports/${reportId}/analysis`);
    return response.json();
  },

  getDashboardStats: async (): Promise<DashboardStats> => {
    const response = await apiRequest('GET', '/api/dashboard/stats');
    return response.json();
  }
};
