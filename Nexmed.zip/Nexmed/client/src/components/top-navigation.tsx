import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bell, Stethoscope, User, Activity, Settings, ChevronDown } from "lucide-react";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function TopNavigation() {
  const [userType, setUserType] = useState<'healthcare' | 'patient'>('healthcare');
  
  const { data: user } = useQuery({
    queryKey: ['/api/user'],
    queryFn: () => api.getCurrentUser(),
  });

  return (
    <nav className="bg-white border-b border-neutral-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Enhanced Logo Section */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-medical-purple rounded-xl flex items-center justify-center shadow-lg">
                  <Stethoscope className="w-5 h-5 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-health-green rounded-full flex items-center justify-center">
                  <Activity className="w-2 h-2 text-white" />
                </div>
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-neutral-800 tracking-tight">MedIntelligence</span>
                <span className="text-xs text-medical-blue font-medium">AI-Powered Analysis</span>
              </div>
            </div>
          </div>
          
          {/* Enhanced Mode Switcher and User Section */}
          <div className="flex items-center space-x-6">
            {/* Professional Mode Switcher */}
            <div className="flex items-center bg-neutral-50 rounded-xl p-1 border border-neutral-200 shadow-sm">
              <Button
                variant="ghost"
                size="sm"
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-all-smooth relative ${
                  userType === 'healthcare' 
                    ? 'bg-medical-blue text-white shadow-medical hover:bg-medical-blue-dark' 
                    : 'text-neutral-600 hover:bg-white hover:text-medical-blue'
                }`}
                onClick={() => setUserType('healthcare')}
              >
                <Stethoscope className="w-4 h-4 mr-2" />
                Healthcare Pro
                {userType === 'healthcare' && (
                  <Badge variant="secondary" className="ml-2 bg-white text-medical-blue text-xs px-2 py-0">
                    Active
                  </Badge>
                )}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-all-smooth relative ${
                  userType === 'patient' 
                    ? 'bg-health-green text-white shadow-success hover:bg-health-green-dark' 
                    : 'text-neutral-600 hover:bg-white hover:text-health-green'
                }`}
                onClick={() => setUserType('patient')}
              >
                <User className="w-4 h-4 mr-2" />
                Patient
                {userType === 'patient' && (
                  <Badge variant="secondary" className="ml-2 bg-white text-health-green text-xs px-2 py-0">
                    Active
                  </Badge>
                )}
              </Button>
            </div>
            
            {/* Notification and Settings */}
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm" className="relative p-2 rounded-lg hover:bg-neutral-100 transition-all-smooth">
                <Bell className="w-5 h-5 text-neutral-600" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-alert-red rounded-full border-2 border-white animate-pulse"></div>
              </Button>
              
              <Button variant="ghost" size="sm" className="p-2 rounded-lg hover:bg-neutral-100 transition-all-smooth">
                <Settings className="w-5 h-5 text-neutral-600" />
              </Button>
            </div>
            
            {/* Enhanced User Profile */}
            <div className="flex items-center space-x-3 pl-3 border-l border-neutral-200">
              <div className="flex items-center space-x-2 cursor-pointer hover:bg-neutral-50 rounded-lg p-2 transition-all-smooth">
                <Avatar className="w-8 h-8 ring-2 ring-white shadow-sm">
                  <AvatarImage src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100" />
                  <AvatarFallback className="bg-gradient-to-br from-neutral-100 to-neutral-200 text-neutral-600">
                    <User className="w-4 h-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="hidden md:flex flex-col">
                  <span className="text-sm font-medium text-neutral-800">{user?.name || 'Dr. Sarah Johnson'}</span>
                  <span className="text-xs text-neutral-500 capitalize">{userType}</span>
                </div>
                <ChevronDown className="w-4 h-4 text-neutral-400" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
