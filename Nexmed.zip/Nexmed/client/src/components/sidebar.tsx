import { useQuery } from "@tanstack/react-query";
import { Upload, BarChart3, History, Users, Settings } from "lucide-react";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  const { data: stats } = useQuery({
    queryKey: ['/api/dashboard/stats'],
    queryFn: () => api.getDashboardStats(),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const navigationItems = [
    { id: 'upload', label: 'Upload Report', icon: Upload },
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'history', label: 'Report History', icon: History },
    { id: 'patients', label: 'Patients', icon: Users },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-white border-r border-neutral-200 min-h-screen">
      <div className="p-6">
        <nav className="space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={activeTab === item.id ? "default" : "ghost"}
                className={`w-full justify-start space-x-3 ${
                  activeTab === item.id 
                    ? 'bg-blue-600 text-white hover:bg-blue-700' 
                    : 'text-neutral-600 hover:bg-neutral-100'
                }`}
                onClick={() => onTabChange(item.id)}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </Button>
            );
          })}
        </nav>

        <div className="mt-8 p-4 bg-green-50 rounded-lg">
          <h4 className="text-sm font-semibold text-green-700 mb-2">Quick Stats</h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-neutral-600">Reports Today</span>
              <span className="font-medium">{stats?.reportsToday || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-600">Abnormalities</span>
              <span className="font-medium text-red-600">{stats?.abnormalities || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-600">Processing</span>
              <span className="font-medium">{stats?.processing || 0}</span>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
