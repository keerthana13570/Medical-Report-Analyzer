import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { CloudUpload, Camera, FileText, Download, FileCheck, AlertCircle, Upload, Sparkles } from "lucide-react";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

export function FileUpload() {
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: (file: File) => api.uploadReport(file),
    onSuccess: () => {
      toast({
        title: "Upload Successful",
        description: "Your medical report has been uploaded and is being analyzed.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/reports'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      setIsUploading(false);
      setUploadProgress(0);
    },
    onError: (error: Error) => {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
      setIsUploading(false);
      setUploadProgress(0);
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    // Validate file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select a file smaller than 10MB.",
        variant: "destructive",
      });
      return;
    }

    // Validate file type
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg', 'text/plain'];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Invalid File Type",
        description: "Please upload a PDF, JPG, PNG, or text file.",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    
    // Simulate upload progress
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return 90;
        }
        return prev + Math.random() * 20;
      });
    }, 200);

    uploadMutation.mutate(file);
  }, [uploadMutation, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'text/plain': ['.txt']
    },
    multiple: false,
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Enhanced Upload Area */}
      <Card className={`border-2 border-dashed transition-all-smooth ${
        isDragActive 
          ? 'border-medical-blue bg-info shadow-medical scale-[1.02]' 
          : 'border-neutral-300 hover:border-medical-blue hover:shadow-medical'
      } ${isUploading ? 'border-health-green bg-success' : ''}`}>
        <CardContent className="p-8">
          <div
            {...getRootProps()}
            className="text-center cursor-pointer relative"
          >
            <input {...getInputProps()} />
            
            {/* Animated Upload Icon */}
            <div className="mb-6 relative">
              {isUploading ? (
                <div className="relative">
                  <Upload className="w-16 h-16 text-health-green mx-auto animate-pulse" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-health-green animate-pulse" />
                  </div>
                </div>
              ) : isDragActive ? (
                <CloudUpload className="w-16 h-16 text-medical-blue mx-auto animate-bounce" />
              ) : (
                <div className="relative group">
                  <CloudUpload className="w-16 h-16 text-medical-blue mx-auto transition-all-smooth group-hover:scale-110" />
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-health-green rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all-smooth">
                    <FileCheck className="w-3 h-3 text-white" />
                  </div>
                </div>
              )}
            </div>
            
            {/* Dynamic Content */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-neutral-800 mb-2">
                {isUploading ? 'Processing Your Report' : 'Upload Medical Report'}
              </h3>
              
              <p className="text-neutral-600 text-lg">
                {isDragActive 
                  ? 'Drop your file here to start analysis'
                  : isUploading 
                    ? 'AI is analyzing your medical data...'
                    : 'Drag & drop your files here or click to browse'
                }
              </p>
              
              {/* File Type Badges */}
              <div className="flex flex-wrap justify-center gap-2 mb-4">
                <Badge variant="outline" className="text-xs bg-neutral-50">
                  <FileText className="w-3 h-3 mr-1" />
                  PDF
                </Badge>
                <Badge variant="outline" className="text-xs bg-neutral-50">
                  <Camera className="w-3 h-3 mr-1" />
                  JPG/PNG
                </Badge>
                <Badge variant="outline" className="text-xs bg-neutral-50">
                  <FileText className="w-3 h-3 mr-1" />
                  TXT
                </Badge>
              </div>
              
              <p className="text-sm text-neutral-500 mb-6">
                Maximum file size: <span className="font-medium text-medical-blue">10MB</span> • 
                Secure & encrypted processing
              </p>
              
              {!isUploading && (
                <Button 
                  className="bg-gradient-to-r from-medical-blue to-medical-purple text-white hover:shadow-medical transition-all-smooth px-8 py-3 text-base font-medium"
                  disabled={isUploading}
                >
                  <Upload className="w-5 h-5 mr-2" />
                  Choose Files
                </Button>
              )}
            </div>
          </div>
          
          {/* Enhanced Progress Section */}
          {isUploading && (
            <div className="mt-8 animate-fade-in">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Sparkles className="w-4 h-4 text-health-green animate-pulse" />
                  <span className="text-sm font-medium text-health-green">Analyzing Report...</span>
                </div>
                <Badge variant="secondary" className="bg-health-green text-white">
                  {Math.round(uploadProgress)}%
                </Badge>
              </div>
              <Progress 
                value={uploadProgress} 
                className="w-full h-3 bg-neutral-200" 
              />
              <p className="text-xs text-neutral-500 mt-2 text-center">
                AI is extracting medical insights from your document
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Enhanced Quick Actions */}
      <Card className="medical-card">
        <CardContent className="p-6">
          <div className="flex items-center space-x-2 mb-6">
            <Sparkles className="w-5 h-5 text-medical-purple" />
            <h3 className="text-lg font-bold text-neutral-800">Smart Features</h3>
          </div>
          
          <div className="space-y-4">
            <Button
              variant="outline"
              className="w-full justify-start p-4 h-auto border border-neutral-200 hover:border-medical-blue hover:bg-info transition-all-smooth group"
              disabled
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-medical-blue/10 rounded-lg flex items-center justify-center group-hover:bg-medical-blue/20 transition-all-smooth">
                  <Camera className="w-5 h-5 text-medical-blue" />
                </div>
                <div className="text-left">
                  <div className="font-medium text-neutral-800">Camera Scan</div>
                  <div className="text-sm text-neutral-500">Capture reports instantly</div>
                </div>
              </div>
              <Badge variant="secondary" className="ml-auto bg-alert-orange text-white text-xs">
                Coming Soon
              </Badge>
            </Button>
            
            <Button
              variant="outline"
              className="w-full justify-start p-4 h-auto border border-neutral-200 hover:border-health-green hover:bg-success transition-all-smooth group"
              disabled
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-health-green/10 rounded-lg flex items-center justify-center group-hover:bg-health-green/20 transition-all-smooth">
                  <FileText className="w-5 h-5 text-health-green" />
                </div>
                <div className="text-left">
                  <div className="font-medium text-neutral-800">Manual Entry</div>
                  <div className="text-sm text-neutral-500">Type or paste text data</div>
                </div>
              </div>
              <Badge variant="secondary" className="ml-auto bg-alert-orange text-white text-xs">
                Coming Soon
              </Badge>
            </Button>
            
            <Button
              variant="outline"
              className="w-full justify-start p-4 h-auto border border-neutral-200 hover:border-medical-purple hover:bg-neutral-50 transition-all-smooth group"
              disabled
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-medical-purple/10 rounded-lg flex items-center justify-center group-hover:bg-medical-purple/20 transition-all-smooth">
                  <Download className="w-5 h-5 text-medical-purple" />
                </div>
                <div className="text-left">
                  <div className="font-medium text-neutral-800">Sample Report</div>
                  <div className="text-sm text-neutral-500">Try with demo data</div>
                </div>
              </div>
            </Button>
          </div>
          
          {/* Security Notice */}
          <div className="mt-6 p-4 bg-success rounded-lg border border-health-green/20">
            <div className="flex items-start space-x-2">
              <FileCheck className="w-4 h-4 text-health-green mt-0.5 flex-shrink-0" />
              <div className="text-sm">
                <p className="font-medium text-health-green mb-1">HIPAA Compliant</p>
                <p className="text-neutral-600 text-xs">
                  Your medical data is encrypted and processed securely. We never store personal information.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
