import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Eye, Download } from "lucide-react";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface ReportHistoryProps {
  onViewReport?: (reportId: number) => void;
}

export function ReportHistory({ onViewReport }: ReportHistoryProps) {
  const { data: reports, isLoading } = useQuery({
    queryKey: ['/api/reports'],
    queryFn: () => api.getReports(),
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'analyzed': return 'bg-green-600 text-white';
      case 'processing': return 'bg-blue-600 text-white';
      case 'uploaded': return 'bg-yellow-600 text-white';
      case 'error': return 'bg-red-600 text-white';
      default: return 'bg-neutral-500 text-white';
    }
  };

  const getReportType = (fileName: string, fileType: string) => {
    if (fileType.includes('pdf')) return 'PDF Report';
    if (fileType.includes('image')) return 'Image Scan';
    if (fileName.toLowerCase().includes('blood')) return 'Blood Test';
    if (fileName.toLowerCase().includes('xray') || fileName.toLowerCase().includes('x-ray')) return 'X-Ray';
    if (fileName.toLowerCase().includes('mri')) return 'MRI Scan';
    if (fileName.toLowerCase().includes('ct')) return 'CT Scan';
    return 'Medical Report';
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <Skeleton className="h-6 w-40" />
            <Skeleton className="h-8 w-20" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center space-x-4">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-8 w-16" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!reports || reports.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Report History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-neutral-500">No reports uploaded yet.</p>
            <p className="text-sm text-neutral-400 mt-2">
              Upload your first medical report to get started.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Sort reports by upload date (newest first)
  const sortedReports = [...reports].sort((a, b) => 
    new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-neutral-800">
            Recent Reports
          </CardTitle>
          <Button variant="ghost" className="text-blue-600 hover:text-blue-700 text-sm font-medium">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-left">Date</TableHead>
                <TableHead className="text-left">Report Type</TableHead>
                <TableHead className="text-left">Status</TableHead>
                <TableHead className="text-left">Size</TableHead>
                <TableHead className="text-left">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedReports.map((report) => (
                <TableRow key={report.id}>
                  <TableCell className="text-sm text-neutral-600">
                    {format(new Date(report.uploadedAt), 'MMM dd, yyyy')}
                  </TableCell>
                  <TableCell className="text-sm text-neutral-800">
                    {getReportType(report.fileName, report.fileType)}
                  </TableCell>
                  <TableCell>
                    <Badge className={`text-xs ${getStatusColor(report.status)}`}>
                      {report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-neutral-600">
                    {(report.fileSize / 1024).toFixed(1)} KB
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-blue-600 hover:text-blue-700 text-sm h-8 px-2"
                        onClick={() => onViewReport?.(report.id)}
                        disabled={report.status === 'error'}
                      >
                        <Eye className="w-3 h-3 mr-1" />
                        View
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-neutral-500 hover:text-neutral-700 text-sm h-8 px-2"
                        disabled
                      >
                        <Download className="w-3 h-3 mr-1" />
                        Download
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
