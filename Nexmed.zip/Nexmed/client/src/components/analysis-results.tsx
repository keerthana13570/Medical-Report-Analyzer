import { useQuery } from "@tanstack/react-query";
import { CheckCircle, AlertTriangle, Lightbulb, Activity, Calendar, TrendingUp, Eye, Heart, Stethoscope, Sparkles, AlertCircle, Brain } from "lucide-react";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

interface AnalysisResultsProps {
  reportId?: number;
}

export function AnalysisResults({ reportId }: AnalysisResultsProps) {
  const { data: reports, isLoading: reportsLoading } = useQuery({
    queryKey: ['/api/reports'],
    queryFn: () => api.getReports(),
  });

  // Get the latest analyzed report if no specific reportId provided
  const latestReport = reports?.find(r => r.status === 'analyzed' && r.analysisId);
  const targetReportId = reportId || latestReport?.id;

  const { data: analysis, isLoading: analysisLoading } = useQuery({
    queryKey: ['/api/reports', targetReportId, 'analysis'],
    queryFn: () => api.getAnalysis(targetReportId!),
    enabled: !!targetReportId,
  });

  const isLoading = reportsLoading || analysisLoading;

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-20 w-full mb-4" />
              <Skeleton className="h-16 w-full" />
            </CardContent>
          </Card>
        </div>
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-32 w-full" />
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!analysis) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Activity className="w-12 h-12 text-neutral-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-neutral-600 mb-2">No Analysis Available</h3>
          <p className="text-neutral-500">Upload a medical report to see AI-powered analysis results.</p>
        </CardContent>
      </Card>
    );
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-alert-red text-white border-alert-red';
      case 'medium': return 'bg-alert-orange text-white border-alert-orange';
      case 'low': return 'bg-health-green text-white border-health-green';
      default: return 'bg-neutral-500 text-white border-neutral-500';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high': return AlertCircle;
      case 'medium': return AlertTriangle;
      case 'low': return CheckCircle;
      default: return Activity;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'dietary': return Heart;
      case 'exercise': return TrendingUp;
      case 'medication': return Stethoscope;
      case 'follow-up': return Calendar;
      case 'lifestyle': return Activity;
      case 'cardiovascular': return Heart;
      case 'metabolic': return Brain;
      default: return Lightbulb;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'border-l-alert-red bg-error';
      case 'medium': return 'border-l-alert-orange bg-warning';
      case 'low': return 'border-l-health-green bg-success';
      default: return 'border-l-medical-blue bg-info';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fade-in">
      {/* Enhanced Analysis Summary */}
      <div className="lg:col-span-2 space-y-6">
        <Card className="medical-card">
          <CardHeader className="bg-gradient-to-r from-medical-blue/5 to-medical-purple/5 border-b border-neutral-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-medical-blue to-medical-purple rounded-lg flex items-center justify-center">
                  <Brain className="w-5 h-5 text-white" />
                </div>
                <div>
                  <CardTitle className="text-xl font-bold text-neutral-800">
                    AI Medical Analysis
                  </CardTitle>
                  <p className="text-sm text-neutral-500">Comprehensive health insights</p>
                </div>
              </div>
              <Badge className="bg-health-green text-white px-3 py-1 shadow-success">
                <CheckCircle className="w-3 h-3 mr-1" />
                Completed
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="bg-gradient-to-br from-info to-neutral-50 rounded-xl p-6 mb-6 border border-medical-blue/20">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-medical-blue rounded-lg flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="font-bold text-neutral-800 mb-2 text-lg">Executive Summary</h4>
                  <p className="text-neutral-700 leading-relaxed">
                    {analysis.summary}
                  </p>
                </div>
              </div>
            </div>
            
            {/* Enhanced Key Findings */}
            <div className="space-y-4">
              <h4 className="font-bold text-neutral-800 text-lg mb-4 flex items-center">
                <Eye className="w-5 h-5 mr-2 text-medical-blue" />
                Key Clinical Findings
              </h4>
              
              {analysis.keyFindings.normal.length > 0 && (
                <div className="flex items-start space-x-4 p-4 bg-success rounded-xl border border-health-green/20 transition-all-smooth hover:shadow-success">
                  <div className="w-8 h-8 bg-health-green rounded-lg flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="font-bold text-health-green text-base">Normal Parameters</span>
                      <Badge variant="outline" className="border-health-green text-health-green text-xs">
                        {analysis.keyFindings.normal.length} items
                      </Badge>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {analysis.keyFindings.normal.map((finding, index) => (
                        <Badge key={index} variant="secondary" className="bg-health-green/10 text-health-green border-health-green/20">
                          {finding}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              
              {analysis.keyFindings.abnormal.length > 0 && (
                <div className="flex items-start space-x-4 p-4 bg-error rounded-xl border border-alert-red/20 transition-all-smooth hover:shadow-error">
                  <div className="w-8 h-8 bg-alert-red rounded-lg flex items-center justify-center flex-shrink-0">
                    <AlertCircle className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="font-bold text-alert-red text-base">Abnormal Findings</span>
                      <Badge variant="outline" className="border-alert-red text-alert-red text-xs">
                        {analysis.keyFindings.abnormal.length} items
                      </Badge>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {analysis.keyFindings.abnormal.map((finding, index) => (
                        <Badge key={index} variant="secondary" className="bg-alert-red/10 text-alert-red border-alert-red/20">
                          {finding}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              
              {analysis.keyFindings.monitoring.length > 0 && (
                <div className="flex items-start space-x-4 p-4 bg-warning rounded-xl border border-alert-orange/20 transition-all-smooth hover:shadow-warning">
                  <div className="w-8 h-8 bg-alert-orange rounded-lg flex items-center justify-center flex-shrink-0">
                    <Eye className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="font-bold text-alert-orange text-base">Requires Monitoring</span>
                      <Badge variant="outline" className="border-alert-orange text-alert-orange text-xs">
                        {analysis.keyFindings.monitoring.length} items
                      </Badge>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {analysis.keyFindings.monitoring.map((finding, index) => (
                        <Badge key={index} variant="secondary" className="bg-alert-orange/10 text-alert-orange border-alert-orange/20">
                          {finding}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Abnormality Detection & Recommendations */}
      <div className="space-y-6">
        {/* Detection Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-neutral-800">
              Detection Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {analysis.abnormalities.length === 0 ? (
                <div className="flex items-center space-x-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div>
                    <span className="text-sm font-medium text-green-700">All Normal</span>
                    <p className="text-xs text-green-600">No abnormalities detected</p>
                  </div>
                </div>
              ) : (
                analysis.abnormalities.map((abnormality, index) => (
                  <div
                    key={index}
                    className={`flex items-center space-x-3 p-3 rounded-lg border ${
                      abnormality.severity === 'high' 
                        ? 'bg-red-50 border-red-200' 
                        : abnormality.severity === 'medium'
                        ? 'bg-yellow-50 border-yellow-200'
                        : 'bg-blue-50 border-blue-200'
                    }`}
                  >
                    <AlertTriangle className={`w-5 h-5 ${
                      abnormality.severity === 'high' 
                        ? 'text-red-600' 
                        : abnormality.severity === 'medium'
                        ? 'text-yellow-600'
                        : 'text-blue-600'
                    }`} />
                    <div>
                      <Badge className={`text-xs ${getSeverityColor(abnormality.severity)} mb-1`}>
                        {abnormality.severity.toUpperCase()}
                      </Badge>
                      <p className="text-xs text-neutral-600">{abnormality.description}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recommendations */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-neutral-800">
              Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {analysis.recommendations.length === 0 ? (
                <p className="text-sm text-neutral-500 text-center py-4">
                  No specific recommendations at this time.
                </p>
              ) : (
                analysis.recommendations.map((rec, index) => (
                  <div key={index} className="p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-start space-x-2">
                      <span className="text-lg">{getCategoryIcon(rec.category)}</span>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="text-sm font-medium text-blue-700 capitalize">
                            {rec.category}
                          </span>
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${
                              rec.priority === 'high' 
                                ? 'border-red-500 text-red-700' 
                                : rec.priority === 'medium'
                                ? 'border-yellow-500 text-yellow-700'
                                : 'border-green-500 text-green-700'
                            }`}
                          >
                            {rec.priority}
                          </Badge>
                        </div>
                        <p className="text-xs text-neutral-600">{rec.text}</p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
