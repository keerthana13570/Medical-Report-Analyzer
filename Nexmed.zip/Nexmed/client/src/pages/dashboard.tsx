import { useState } from "react";
import { AlertTriangle, Upload, Activity, History, TrendingUp, FileText, Brain, Sparkles } from "lucide-react";
import { TopNavigation } from "@/components/top-navigation";
import { Sidebar } from "@/components/sidebar";
import { FileUpload } from "@/components/file-upload";
import { AnalysisResults } from "@/components/analysis-results";
import { ReportHistory } from "@/components/report-history";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Dashboard() {
  const [selectedReportId, setSelectedReportId] = useState<number | undefined>();

  const handleViewReport = (reportId: number) => {
    setSelectedReportId(reportId);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-neutral-50 to-neutral-100">
      <TopNavigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Enhanced Header */}
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-medical-blue to-medical-purple rounded-xl flex items-center justify-center shadow-lg">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-medical-blue to-medical-purple bg-clip-text text-transparent">
                Medical Intelligence Hub
              </h1>
            </div>
          </div>
          <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
            Advanced AI-powered medical report analysis with personalized health insights and recommendations
          </p>
        </div>

        {/* Enhanced Multi-Tab Interface */}
        <Tabs defaultValue="upload" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8 bg-white border border-neutral-200 shadow-sm rounded-xl p-1">
            <TabsTrigger 
              value="upload" 
              className="flex items-center space-x-2 px-4 py-3 rounded-lg transition-all-smooth data-[state=active]:bg-gradient-to-r data-[state=active]:from-medical-blue data-[state=active]:to-medical-purple data-[state=active]:text-white data-[state=active]:shadow-medical"
            >
              <Upload className="w-4 h-4" />
              <span className="font-medium">Upload</span>
            </TabsTrigger>
            <TabsTrigger 
              value="analysis" 
              className="flex items-center space-x-2 px-4 py-3 rounded-lg transition-all-smooth data-[state=active]:bg-gradient-to-r data-[state=active]:from-health-green data-[state=active]:to-medical-teal data-[state=active]:text-white data-[state=active]:shadow-success"
            >
              <Brain className="w-4 h-4" />
              <span className="font-medium">Analysis</span>
            </TabsTrigger>
            <TabsTrigger 
              value="history" 
              className="flex items-center space-x-2 px-4 py-3 rounded-lg transition-all-smooth data-[state=active]:bg-gradient-to-r data-[state=active]:from-medical-purple data-[state=active]:to-alert-orange data-[state=active]:text-white data-[state=active]:shadow-warning"
            >
              <History className="w-4 h-4" />
              <span className="font-medium">History</span>
            </TabsTrigger>
            <TabsTrigger 
              value="insights" 
              className="flex items-center space-x-2 px-4 py-3 rounded-lg transition-all-smooth data-[state=active]:bg-gradient-to-r data-[state=active]:from-alert-orange data-[state=active]:to-medical-blue data-[state=active]:text-white data-[state=active]:shadow-medical"
            >
              <TrendingUp className="w-4 h-4" />
              <span className="font-medium">Insights</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="animate-fade-in">
            <div className="space-y-8">
              <div className="text-center mb-8">
                <div className="flex items-center justify-center space-x-2 mb-3">
                  <Upload className="w-6 h-6 text-medical-blue" />
                  <h2 className="text-2xl font-bold text-neutral-800">Upload Medical Reports</h2>
                </div>
                <p className="text-neutral-600 max-w-2xl mx-auto">
                  Securely upload your medical documents for instant AI-powered analysis and insights
                </p>
              </div>
              <FileUpload />
              <div className="mt-12">
                <div className="flex items-center space-x-2 mb-6">
                  <Sparkles className="w-5 h-5 text-medical-purple" />
                  <h3 className="text-xl font-bold text-neutral-800">Latest Analysis</h3>
                </div>
                <AnalysisResults />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="analysis" className="animate-fade-in">
            <div className="space-y-8">
              <div className="text-center mb-8">
                <div className="flex items-center justify-center space-x-2 mb-3">
                  <Brain className="w-6 h-6 text-health-green" />
                  <h2 className="text-2xl font-bold text-neutral-800">AI Analysis Results</h2>
                  {selectedReportId && (
                    <Badge className="bg-health-green text-white">
                      Report #{selectedReportId}
                    </Badge>
                  )}
                </div>
                <p className="text-neutral-600 max-w-2xl mx-auto">
                  Comprehensive medical analysis with AI-generated insights and recommendations
                </p>
              </div>
              <AnalysisResults reportId={selectedReportId} />
            </div>
          </TabsContent>

          <TabsContent value="history" className="animate-fade-in">
            <div className="space-y-8">
              <div className="text-center mb-8">
                <div className="flex items-center justify-center space-x-2 mb-3">
                  <History className="w-6 h-6 text-medical-purple" />
                  <h2 className="text-2xl font-bold text-neutral-800">Report History</h2>
                </div>
                <p className="text-neutral-600 max-w-2xl mx-auto">
                  Access and manage all your uploaded medical reports and analysis results
                </p>
              </div>
              <ReportHistory onViewReport={handleViewReport} />
            </div>
          </TabsContent>

          <TabsContent value="insights" className="animate-fade-in">
            <div className="space-y-8">
              <div className="text-center mb-8">
                <div className="flex items-center justify-center space-x-2 mb-3">
                  <TrendingUp className="w-6 h-6 text-alert-orange" />
                  <h2 className="text-2xl font-bold text-neutral-800">Health Insights</h2>
                </div>
                <p className="text-neutral-600 max-w-2xl mx-auto">
                  Personalized health trends and predictive analytics
                </p>
              </div>
              
              <Card className="medical-card">
                <CardContent className="p-12 text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-alert-orange to-medical-blue rounded-full flex items-center justify-center mx-auto mb-6">
                    <Sparkles className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-neutral-800 mb-4">Advanced Insights Coming Soon</h3>
                  <p className="text-neutral-600 mb-6 max-w-md mx-auto">
                    We're developing advanced health trend analysis, predictive insights, and personalized recommendations.
                  </p>
                  <Badge className="bg-gradient-to-r from-alert-orange to-medical-blue text-white px-6 py-2">
                    In Development
                  </Badge>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}