# Medical Report Analysis System

## Overview

This is a full-stack medical report analysis application that leverages AI to analyze uploaded medical reports (PDFs, images, text files) and provide intelligent insights, abnormality detection, and recommendations. The system features a React frontend with shadcn/ui components, an Express.js backend, PostgreSQL database with Drizzle ORM, and integrates with OpenAI for AI-powered analysis.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with custom medical theme colors
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **File Handling**: React Dropzone for drag-and-drop file uploads
- **Build Tool**: Vite with custom configuration for development and production

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **File Processing**: Multer for multipart file uploads with 10MB limit
- **OCR**: Tesseract.js for text extraction from images
- **AI Integration**: OpenAI GPT-4o for medical report analysis
- **Development**: Hot reload with Vite middleware integration

### Data Storage Solutions
- **Database**: PostgreSQL with Neon serverless database
- **ORM**: Drizzle ORM with migrations support
- **Schema**: Three main tables - users, medical_reports, analysis_results
- **Session Storage**: PostgreSQL sessions with connect-pg-simple
- **Development Storage**: In-memory storage fallback for development

## Key Components

### Database Schema
- **Users**: Authentication and user profile management (healthcare/patient types)
- **Medical Reports**: File metadata, upload status, extracted text storage
- **Analysis Results**: AI-generated summaries, findings, abnormalities, and recommendations

### File Processing Pipeline
1. File upload validation (PDF, JPG, PNG, TXT - 10MB max)
2. Text extraction using OCR for images or direct parsing for text/PDF
3. AI analysis using OpenAI for medical insights
4. Structured result storage with categorized findings

### AI Analysis Features
- Medical report summarization
- Normal/abnormal/monitoring findings categorization
- Severity-based abnormality detection (low/medium/high)
- Priority-based recommendations
- Healthcare-specific insights and suggestions

### User Interface Components
- **Dashboard**: Multi-tab interface with upload, analysis, and history views
- **File Upload**: Drag-and-drop interface with progress tracking
- **Analysis Results**: Structured display of AI findings with badges and icons
- **Report History**: Tabular view of all processed reports with status tracking
- **Navigation**: Sidebar with healthcare/patient mode switching

## Data Flow

1. **Upload Flow**: User uploads file → Multer processes → File validation → Database record creation
2. **Processing Flow**: Text extraction → AI analysis → Results storage → Status update
3. **Display Flow**: Query results → React components → User interface updates
4. **Real-time Updates**: TanStack Query polling for processing status changes

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React 18, React DOM, TypeScript
- **UI Framework**: Radix UI components, Tailwind CSS, class-variance-authority
- **Backend**: Express.js, Multer, connect-pg-simple
- **Database**: Drizzle ORM, @neondatabase/serverless, PostgreSQL
- **AI/ML**: OpenAI API, Tesseract.js for OCR
- **Development**: Vite, ESBuild, PostCSS, Autoprefixer

### API Integrations
- **OpenAI API**: GPT-4o model for medical report analysis
- **Neon Database**: Serverless PostgreSQL hosting
- **Replit Services**: Development environment integration

## Deployment Strategy

### Development Environment
- **Hot Reload**: Vite dev server with Express middleware integration
- **Database**: Drizzle push for schema synchronization
- **Environment Variables**: DATABASE_URL, OPENAI_API_KEY required

### Production Build
- **Frontend**: Vite build to dist/public directory
- **Backend**: ESBuild compilation to dist/index.js
- **Static Serving**: Express serves built React application
- **Database**: Drizzle migrations for schema management

### Environment Configuration
- **Development**: NODE_ENV=development with tsx runtime
- **Production**: NODE_ENV=production with compiled JavaScript
- **Database**: PostgreSQL connection via DATABASE_URL environment variable
- **AI Services**: OpenAI API key configuration required

## Changelog
- June 28, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.