import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  userType: text("user_type").notNull().default("patient"), // 'patient' | 'healthcare'
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const medicalReports = pgTable("medical_reports", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  fileName: text("file_name").notNull(),
  fileType: text("file_type").notNull(),
  fileSize: integer("file_size").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  status: text("status").notNull().default("uploaded"), // 'uploaded' | 'processing' | 'analyzed' | 'error'
  extractedText: text("extracted_text"),
  analysisId: integer("analysis_id"),
});

export const analysisResults = pgTable("analysis_results", {
  id: serial("id").primaryKey(),
  reportId: integer("report_id").notNull(),
  summary: text("summary").notNull(),
  keyFindings: jsonb("key_findings").$type<{
    normal: string[];
    abnormal: string[];
    monitoring: string[];
  }>(),
  abnormalities: jsonb("abnormalities").$type<{
    severity: 'low' | 'medium' | 'high';
    description: string;
    category: string;
  }[]>(),
  recommendations: jsonb("recommendations").$type<{
    category: string;
    text: string;
    priority: 'low' | 'medium' | 'high';
  }[]>(),
  analyzedAt: timestamp("analyzed_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertMedicalReportSchema = createInsertSchema(medicalReports).omit({
  id: true,
  uploadedAt: true,
  analysisId: true,
});

export const insertAnalysisResultSchema = createInsertSchema(analysisResults).omit({
  id: true,
  analyzedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertMedicalReport = z.infer<typeof insertMedicalReportSchema>;
export type MedicalReport = typeof medicalReports.$inferSelect;
export type InsertAnalysisResult = z.infer<typeof insertAnalysisResultSchema>;
export type AnalysisResult = typeof analysisResults.$inferSelect;
