import { users, medicalReports, analysisResults, type User, type InsertUser, type MedicalReport, type InsertMedicalReport, type AnalysisResult, type InsertAnalysisResult } from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Medical report operations
  createMedicalReport(report: InsertMedicalReport): Promise<MedicalReport>;
  getMedicalReport(id: number): Promise<MedicalReport | undefined>;
  getMedicalReportsByUser(userId: number): Promise<MedicalReport[]>;
  updateMedicalReportStatus(id: number, status: string, extractedText?: string, analysisId?: number): Promise<void>;

  // Analysis operations
  createAnalysisResult(analysis: InsertAnalysisResult): Promise<AnalysisResult>;
  getAnalysisResult(id: number): Promise<AnalysisResult | undefined>;
  getAnalysisResultByReportId(reportId: number): Promise<AnalysisResult | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private medicalReports: Map<number, MedicalReport>;
  private analysisResults: Map<number, AnalysisResult>;
  private currentUserId: number;
  private currentReportId: number;
  private currentAnalysisId: number;

  constructor() {
    this.users = new Map();
    this.medicalReports = new Map();
    this.analysisResults = new Map();
    this.currentUserId = 1;
    this.currentReportId = 1;
    this.currentAnalysisId = 1;

    // Create default user
    this.createUser({
      username: "dr.johnson",
      password: "password123",
      userType: "healthcare",
      name: "Dr. Sarah Johnson"
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async createMedicalReport(insertReport: InsertMedicalReport): Promise<MedicalReport> {
    const id = this.currentReportId++;
    const report: MedicalReport = {
      ...insertReport,
      id,
      uploadedAt: new Date(),
      analysisId: null
    };
    this.medicalReports.set(id, report);
    return report;
  }

  async getMedicalReport(id: number): Promise<MedicalReport | undefined> {
    return this.medicalReports.get(id);
  }

  async getMedicalReportsByUser(userId: number): Promise<MedicalReport[]> {
    return Array.from(this.medicalReports.values()).filter(
      report => report.userId === userId
    );
  }

  async updateMedicalReportStatus(id: number, status: string, extractedText?: string, analysisId?: number): Promise<void> {
    const report = this.medicalReports.get(id);
    if (report) {
      const updatedReport = { 
        ...report, 
        status,
        ...(extractedText && { extractedText }),
        ...(analysisId && { analysisId })
      };
      this.medicalReports.set(id, updatedReport);
    }
  }

  async createAnalysisResult(insertAnalysis: InsertAnalysisResult): Promise<AnalysisResult> {
    const id = this.currentAnalysisId++;
    const analysis: AnalysisResult = {
      ...insertAnalysis,
      id,
      analyzedAt: new Date()
    };
    this.analysisResults.set(id, analysis);
    return analysis;
  }

  async getAnalysisResult(id: number): Promise<AnalysisResult | undefined> {
    return this.analysisResults.get(id);
  }

  async getAnalysisResultByReportId(reportId: number): Promise<AnalysisResult | undefined> {
    return Array.from(this.analysisResults.values()).find(
      analysis => analysis.reportId === reportId
    );
  }
}

export const storage = new MemStorage();
