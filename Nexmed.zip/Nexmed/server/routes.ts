import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMedicalReportSchema } from "@shared/schema";
import multer from "multer";
import { processUploadedFile, getReportWithAnalysis } from "./services/analysis";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'image/jpeg',
      'image/png',
      'image/jpg',
      'text/plain'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, JPG, PNG, and text files are allowed.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get current user (mock authentication)
  app.get("/api/user", async (req, res) => {
    try {
      // For demo purposes, return the default user
      const user = await storage.getUser(1);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user", error: (error as Error).message });
    }
  });

  // Upload medical report
  app.post("/api/reports/upload", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const userId = 1; // Mock user ID for demo

      const reportData = {
        userId,
        fileName: req.file.originalname,
        fileType: req.file.mimetype,
        fileSize: req.file.size,
        status: "uploaded" as const,
        extractedText: null
      };

      const report = await storage.createMedicalReport(reportData);

      // Process file asynchronously
      processUploadedFile(report.id, req.file.buffer, req.file.mimetype)
        .catch(error => {
          console.error('File processing failed:', error);
        });

      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to upload report", error: (error as Error).message });
    }
  });

  // Get all reports for current user
  app.get("/api/reports", async (req, res) => {
    try {
      const userId = 1; // Mock user ID for demo
      const reports = await storage.getMedicalReportsByUser(userId);
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to get reports", error: (error as Error).message });
    }
  });

  // Get specific report with analysis
  app.get("/api/reports/:id", async (req, res) => {
    try {
      const reportId = parseInt(req.params.id);
      const result = await getReportWithAnalysis(reportId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to get report", error: (error as Error).message });
    }
  });

  // Get analysis result for a report
  app.get("/api/reports/:id/analysis", async (req, res) => {
    try {
      const reportId = parseInt(req.params.id);
      const analysis = await storage.getAnalysisResultByReportId(reportId);
      
      if (!analysis) {
        return res.status(404).json({ message: "Analysis not found" });
      }

      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: "Failed to get analysis", error: (error as Error).message });
    }
  });

  // Get dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const userId = 1; // Mock user ID for demo
      const reports = await storage.getMedicalReportsByUser(userId);
      
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const reportsToday = reports.filter(report => 
        report.uploadedAt && report.uploadedAt >= today
      ).length;
      
      const processing = reports.filter(report => 
        report.status === 'processing'
      ).length;
      
      // Count abnormalities from recent analyses
      let abnormalities = 0;
      for (const report of reports.slice(0, 10)) { // Check last 10 reports
        if (report.analysisId) {
          const analysis = await storage.getAnalysisResult(report.analysisId);
          if (analysis && analysis.abnormalities) {
            abnormalities += analysis.abnormalities.length;
          }
        }
      }

      res.json({
        reportsToday,
        processing,
        abnormalities
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get stats", error: (error as Error).message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
