import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface MedicalAnalysis {
  summary: string;
  keyFindings: {
    normal: string[];
    abnormal: string[];
    monitoring: string[];
  };
  abnormalities: {
    severity: 'low' | 'medium' | 'high';
    description: string;
    category: string;
  }[];
  recommendations: {
    category: string;
    text: string;
    priority: 'low' | 'medium' | 'high';
  }[];
}

export async function analyzeMedicalReport(extractedText: string): Promise<MedicalAnalysis> {
  try {
    const prompt = `
You are a medical AI assistant analyzing a medical report. Please analyze the following medical report text and provide a comprehensive analysis in JSON format.

Medical Report Text:
${extractedText}

Please provide your analysis in the following JSON structure:
{
  "summary": "A comprehensive summary of the medical report in 2-3 sentences",
  "keyFindings": {
    "normal": ["List of normal findings"],
    "abnormal": ["List of abnormal findings"],
    "monitoring": ["List of findings that need monitoring"]
  },
  "abnormalities": [
    {
      "severity": "low|medium|high",
      "description": "Description of the abnormality",
      "category": "Category like 'cardiovascular', 'metabolic', etc."
    }
  ],
  "recommendations": [
    {
      "category": "dietary|exercise|medication|follow-up|lifestyle",
      "text": "Specific recommendation text",
      "priority": "low|medium|high"
    }
  ]
}

Focus on:
1. Medical terminology and values
2. Reference ranges and normal/abnormal values
3. Clinical significance of findings
4. Actionable recommendations
5. Areas requiring follow-up or monitoring

Ensure all recommendations are general health advice and include appropriate disclaimers about consulting healthcare professionals.
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a medical AI assistant that analyzes medical reports and provides structured analysis. Always respond in valid JSON format."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
      max_tokens: 2000
    });

    const analysis = JSON.parse(response.choices[0].message.content || "{}");
    
    // Validate and sanitize the response
    return {
      summary: analysis.summary || "Analysis could not be completed",
      keyFindings: {
        normal: analysis.keyFindings?.normal || [],
        abnormal: analysis.keyFindings?.abnormal || [],
        monitoring: analysis.keyFindings?.monitoring || []
      },
      abnormalities: analysis.abnormalities || [],
      recommendations: analysis.recommendations || []
    };
  } catch (error) {
    console.error("OpenAI analysis error:", error);
    throw new Error("Failed to analyze medical report: " + (error as Error).message);
  }
}

export async function detectAbnormalities(text: string): Promise<string[]> {
  // Basic keyword-based abnormality detection
  const abnormalKeywords = [
    'elevated', 'high', 'low', 'abnormal', 'irregular', 'concerning',
    'enlarged', 'decreased', 'increased', 'deficient', 'excessive',
    'inflammation', 'infection', 'mass', 'lesion', 'calcification'
  ];

  const criticalKeywords = [
    'critical', 'urgent', 'immediate', 'severe', 'acute', 'emergency'
  ];

  const detected: string[] = [];
  const lowerText = text.toLowerCase();

  abnormalKeywords.forEach(keyword => {
    if (lowerText.includes(keyword)) {
      detected.push(`Potential abnormality detected: ${keyword}`);
    }
  });

  criticalKeywords.forEach(keyword => {
    if (lowerText.includes(keyword)) {
      detected.push(`Critical finding detected: ${keyword}`);
    }
  });

  return detected;
}
