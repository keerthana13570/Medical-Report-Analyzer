import { storage } from '../storage';
import { analyzeMedicalReport, detectAbnormalities } from './openai';
import { extractTextFromImage, extractTextFromPDF } from './ocr';

export async function processUploadedFile(
  reportId: number,
  fileBuffer: Buffer,
  fileType: string
): Promise<void> {
  try {
    // Update status to processing
    await storage.updateMedicalReportStatus(reportId, 'processing');

    let extractedText: string;

    // Extract text based on file type
    if (fileType.includes('pdf')) {
      extractedText = await extractTextFromPDF(fileBuffer);
    } else if (fileType.includes('image')) {
      extractedText = await extractTextFromImage(fileBuffer);
    } else {
      // For text files
      extractedText = fileBuffer.toString('utf-8');
    }

    if (!extractedText || extractedText.trim().length < 10) {
      throw new Error('Insufficient text extracted from file');
    }

    // Update report with extracted text
    await storage.updateMedicalReportStatus(reportId, 'processing', extractedText);

    // Perform AI analysis
    const analysis = await analyzeMedicalReport(extractedText);

    // Detect additional abnormalities
    const detectedAbnormalities = await detectAbnormalities(extractedText);

    // Enhance abnormalities with detected ones
    const enhancedAbnormalities = [
      ...analysis.abnormalities,
      ...detectedAbnormalities.map(desc => ({
        severity: 'medium' as const,
        description: desc,
        category: 'general'
      }))
    ];

    // Create analysis result
    const analysisResult = await storage.createAnalysisResult({
      reportId,
      summary: analysis.summary,
      keyFindings: analysis.keyFindings,
      abnormalities: enhancedAbnormalities,
      recommendations: analysis.recommendations
    });

    // Update report status and link to analysis
    await storage.updateMedicalReportStatus(reportId, 'analyzed', undefined, analysisResult.id);

  } catch (error) {
    console.error('File processing error:', error);
    await storage.updateMedicalReportStatus(reportId, 'error');
    throw error;
  }
}

export async function getReportWithAnalysis(reportId: number) {
  const report = await storage.getMedicalReport(reportId);
  if (!report) {
    throw new Error('Report not found');
  }

  let analysis = null;
  if (report.analysisId) {
    analysis = await storage.getAnalysisResult(report.analysisId);
  }

  return {
    report,
    analysis
  };
}
