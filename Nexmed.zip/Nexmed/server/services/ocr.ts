import { createWorker } from 'tesseract.js';

export async function extractTextFromImage(imageBuffer: Buffer): Promise<string> {
  try {
    const worker = await createWorker('eng');
    
    const { data: { text } } = await worker.recognize(imageBuffer);
    
    await worker.terminate();
    
    return text.trim();
  } catch (error) {
    console.error('OCR extraction error:', error);
    throw new Error('Failed to extract text from image: ' + (error as Error).message);
  }
}

export async function extractTextFromPDF(pdfBuffer: Buffer): Promise<string> {
  try {
    // For PDF text extraction, we would normally use pdf-parse
    // Since it's not in package.json, we'll implement a basic fallback
    const pdfText = pdfBuffer.toString('utf-8');
    
    // Basic PDF text extraction (this is simplified)
    // In a real implementation, you'd use pdf-parse or similar
    const textMatch = pdfText.match(/BT\s+(.+?)\s+ET/g);
    if (textMatch) {
      return textMatch.join(' ').replace(/BT\s+|\s+ET/g, '');
    }
    
    // If no PDF text found, try to extract any readable text
    const readableText = pdfBuffer.toString('utf-8')
      .replace(/[^\x20-\x7E\n\r]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    
    if (readableText.length > 50) {
      return readableText;
    }
    
    throw new Error('No readable text found in PDF');
  } catch (error) {
    console.error('PDF extraction error:', error);
    throw new Error('Failed to extract text from PDF: ' + (error as Error).message);
  }
}
